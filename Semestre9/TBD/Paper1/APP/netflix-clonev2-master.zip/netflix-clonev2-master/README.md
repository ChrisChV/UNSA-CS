# Netflix React Clone

- demo: http://netflix-clonev2.surge.sh/

-Prototype : http://netflix-clone.surge.sh/#/ (simple bootstrap, mainly to write out the react functions)

-Template slicing: https://github.com/kuanhsuh/netflix-clone-html5 (Use Bootstrap to clone netflix major component)


Let me know what you guys think!!!

### User Story:

- User can search for movies 
- User can see upcoming movies in the Home page
- Search Should have autosuggest
- Movie Show page should have movie details, casts, trailers


### Video Walkthrough
![](https://github.com/kuanhsuh/netflix-clonev2/blob/master/Demo.gif?raw=true)

