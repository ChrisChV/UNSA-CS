#include <iostream>
#include <fstream>
#include "connector.h"
#include "FileOp.h"
#include "MyTime.h"

int main(){
	/*
	auto bdInter = getBd("../ml/ml_10mP/rb.test", ';');

	cout<<"Generando vals"<<endl;
	map<int, InterRegisterMap> valsByUser;
	Valoration val = 0;	

	UserId id = 0;
	MovieId id2 = 0;

	for(auto iter = bdInter.begin(); iter != bdInter.end(); ++iter){
		id = stoi((*iter)[0]);
		id2 = stoi((*iter)[1]);
		val = stof((*iter)[2]);
		valsByUser[id][id2] = val;
	}

	*/

	int numUsers = 671;

	MYSQL * conn = getConnect("ml");
	MYSQL * conn2;
	MYSQL_ROW row1;
	MYSQL_ROW row2;
	MYSQL_RES * res1 = nullptr;
	MYSQL_RES * res2 = nullptr;
	double res = 0;

	ofstream outFile("expOut");

	for(int i = 128; i < numUsers; i++){
		cout<<i<<"/"<<numUsers<<endl;
		string query1 = "select MovieId from ratings where userId = " + to_string(i);
		res1 = getQueryRes(conn, query1);
		while((row1 = mysql_fetch_row(res1))){
			conn2 = getConnect("ml");
			res2 = getQueryRes(conn2, "call recommendSlopeTest(" + to_string(i) + "," + to_string(atoi(row1[0])) + ")");
			closeConnect(conn2);
			row2 = mysql_fetch_row(res2);
			res = atof(row2[3]);
			outFile<<i<<" "<<atoi(row1[0])<<" "<<res<<endl;
			mysql_free_result(res2);
		}
		mysql_free_result(res1);
	}
	
	outFile.close();
	closeConnect(conn);

}
