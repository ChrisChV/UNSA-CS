## Netflix Clone HTML&CSS 

This is my attempt to clone Netflix for my react project. I only clone some components for this project.


![Home](https://github.com/kuanhsuh/netflix-clone-html/blob/master/home.jpg?raw=true "Home")


![Show](https://github.com/kuanhsuh/netflix-clone-html/blob/master/show.jpg?raw=true "Show")