g++ -std=c++11 ConvexHull.cpp -o run
