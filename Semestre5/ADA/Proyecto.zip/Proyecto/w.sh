while true
do
	pkill ssh
done
