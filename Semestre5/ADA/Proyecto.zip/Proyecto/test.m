#!/usr/bin/octave -qf
x = [16.000000,39.000000,74.000000,87.000000,57.000000,67.000000,82.000000,77.000000,55.000000,18.000000,43.000000,96.000000,21.000000,47.000000,11.000000,84.000000,40.000000,64.000000,65.000000,71.000000];
y = [92.000000,45.000000,3.000000,33.000000,47.000000,16.000000,31.000000,95.000000,80.000000,82.000000,81.000000,23.000000,68.000000,88.000000,86.000000,84.000000,70.000000,50.000000,40.000000,13.000000];
plot(x,y,'*')
x = [11,21];
y = [86,68];
hold on
plot(x,y,'r')
x = [21,39];
y = [68,45];
hold on
plot(x,y,'r')
x = [39,74];
y = [45,3];
hold on
plot(x,y,'r')
x = [74,96];
y = [3,23];
hold on
plot(x,y,'r')
x = [96,84];
y = [23,84];
hold on
plot(x,y,'r')
x = [84,77];
y = [84,95];
hold on
plot(x,y,'r')
x = [77,16];
y = [95,92];
hold on
plot(x,y,'r')
x = [16,11];
y = [92,86];
hold on
plot(x,y,'r')
x1 =[11,21];
x2 =[21,39];
x3 =[39,11];
y1 =[86,68];
y2 =[68,45];
y3 =[45,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,39];
x2 =[39,74];
x3 =[74,11];
y1 =[86,45];
y2 =[45,3];
y3 =[3,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,74];
x2 =[74,67];
x3 =[67,11];
y1 =[86,3];
y2 =[3,16];
y3 =[16,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,67];
x2 =[67,71];
x3 =[71,11];
y1 =[86,16];
y2 =[16,13];
y3 =[13,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,71];
x2 =[71,65];
x3 =[65,11];
y1 =[86,13];
y2 =[13,40];
y3 =[40,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,65];
x2 =[65,57];
x3 =[57,11];
y1 =[86,40];
y2 =[40,47];
y3 =[47,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,57];
x2 =[57,82];
x3 =[82,11];
y1 =[86,47];
y2 =[47,31];
y3 =[31,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,82];
x2 =[82,96];
x3 =[96,11];
y1 =[86,31];
y2 =[31,23];
y3 =[23,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,96];
x2 =[96,87];
x3 =[87,11];
y1 =[86,23];
y2 =[23,33];
y3 =[33,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,87];
x2 =[87,64];
x3 =[64,11];
y1 =[86,33];
y2 =[33,50];
y3 =[50,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,64];
x2 =[64,18];
x3 =[18,11];
y1 =[86,50];
y2 =[50,82];
y3 =[82,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,18];
x2 =[18,40];
x3 =[40,11];
y1 =[86,82];
y2 =[82,70];
y3 =[70,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,40];
x2 =[40,43];
x3 =[43,11];
y1 =[86,70];
y2 =[70,81];
y3 =[81,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,43];
x2 =[43,55];
x3 =[55,11];
y1 =[86,81];
y2 =[81,80];
y3 =[80,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,55];
x2 =[55,84];
x3 =[84,11];
y1 =[86,80];
y2 =[80,84];
y3 =[84,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,84];
x2 =[84,47];
x3 =[47,11];
y1 =[86,84];
y2 =[84,88];
y3 =[88,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,47];
x2 =[47,77];
x3 =[77,11];
y1 =[86,88];
y2 =[88,95];
y3 =[95,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[11,77];
x2 =[77,16];
x3 =[16,11];
y1 =[86,95];
y2 =[95,92];
y3 =[92,86];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[74,67];
x2 =[67,71];
x3 =[71,74];
y1 =[3,16];
y2 =[16,13];
y3 =[13,3];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[74,71];
x2 =[71,65];
x3 =[65,74];
y1 =[3,13];
y2 =[13,40];
y3 =[40,3];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[65,57];
x2 =[57,82];
x3 =[82,65];
y1 =[40,47];
y2 =[47,31];
y3 =[31,40];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[74,65];
x2 =[65,82];
x3 =[82,74];
y1 =[3,40];
y2 =[40,31];
y3 =[31,3];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[74,82];
x2 =[82,96];
x3 =[96,74];
y1 =[3,31];
y2 =[31,23];
y3 =[23,3];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[64,18];
x2 =[18,40];
x3 =[40,64];
y1 =[50,82];
y2 =[82,70];
y3 =[70,50];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[87,64];
x2 =[64,40];
x3 =[40,87];
y1 =[33,50];
y2 =[50,70];
y3 =[70,33];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[87,40];
x2 =[40,43];
x3 =[43,87];
y1 =[33,70];
y2 =[70,81];
y3 =[81,33];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[87,43];
x2 =[43,55];
x3 =[55,87];
y1 =[33,81];
y2 =[81,80];
y3 =[80,33];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[96,87];
x2 =[87,55];
x3 =[55,96];
y1 =[23,33];
y2 =[33,80];
y3 =[80,23];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[96,55];
x2 =[55,84];
x3 =[84,96];
y1 =[23,80];
y2 =[80,84];
y3 =[84,23];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
x1 =[84,47];
x2 =[47,77];
x3 =[77,84];
y1 =[84,88];
y2 =[88,95];
y3 =[95,84];
hold on
plot(x1,y1,'r')
hold on
plot(x2,y2,'r')
hold on
plot(x3,y3,'r')
pause()