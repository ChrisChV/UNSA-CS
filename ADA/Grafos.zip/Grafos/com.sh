g++ -std=c++17 coloring.cpp -o coloring
g++ -std=c++17 bipartito.cpp -o bipartito
g++ -std=c++17 conmpFuerCon.cpp -o conexo
g++ -std=c++17 flujoMaximo.cpp -o flujo
